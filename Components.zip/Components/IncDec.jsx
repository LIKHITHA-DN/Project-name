import react, { useEffect, useState } from 'react'

let IncDec=()=>{
    let [Count,setCount]=useState(0)
    let inc=()=>{
        setCount(Count+1)
    }
    let dec=()=>{
        setCount(Count-1)
    }
    useEffect(()=>(
        alert("click")
    ))

    return(
        <div>
            <>
            <h1>count : {Count}</h1>
            <button onClick={inc}>INC</button>
            <button onClick={dec}>DEC</button>
            </>

        </div>
    )
}
export default IncDec